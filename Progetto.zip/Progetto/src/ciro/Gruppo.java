package ciro;
import java.util.ArrayList;

public abstract class Gruppo {
	private String nome;
	private Utente proprietario;
	private ArrayList<String> spese;
	
	public Gruppo(String nome, Utente proprietario) {
		this.nome = nome;
		this.proprietario = proprietario;
	}
	
	public abstract void aggiungiSpesa();
	
	
}
