package ciro;

public class Utente {
	
	private String mail;
	private String nome;
	private String cognome;
	private String password;
	
	public Utente(String mail, String nome, String cognome, String password) {
		this.mail = mail;
		this.nome = nome;
		this.cognome = cognome;
		this.password = password;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	
	
	
	
	

}
